
import { Link } from "react-router-dom";



  const tests = [
  {
    id: 1,
    title: "Urban Gardening",
    level: "Easy",
    questions: 4,
    path: "/ielts/reading",
  },
  {
    id: 2,
    title: "Technology in Education",
    level: "Medium",
    questions: 6,
    path: "/ielts/reading/technology",
  },
  {
    id: 3,
    title: "Climate Change",
    level: "Hard",
    questions: 8,
    path: "/ielts/reading/climate",
  },
];

export default function ReadingTestsPage() {
  return (
    <main className="mx-auto max-w-5xl p-8">
      <h1 className="text-3xl font-bold">
        IELTS Reading Tests
      </h1>

      <p className="mt-2 text-gray-500">
        Choose a test to start practicing.
      </p>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        {tests.map((test) => (
          <div
            key={test.id}
            className="rounded-2xl bg-white p-6 shadow-sm"
          >
            <h2 className="text-xl font-semibold">
              {test.title}
            </h2>

            <p className="mt-2 text-gray-500">
              <span
  className={`inline-block rounded-full px-3 py-1 text-sm font-medium ${
    test.level === "Easy"
      ? "bg-green-100 text-green-700"
      : test.level === "Medium"
      ? "bg-yellow-100 text-yellow-700"
      : "bg-red-100 text-red-700"
  }`}
>
  {test.level}
</span>
            </p>

            <p className="text-gray-500">
              Questions: {test.questions}
            </p>

            <Link
              to={test.path}
              className="mt-5 inline-block rounded-xl bg-violet-600 px-5 py-3 text-white"
            >
              Start Test
            </Link>
          </div>
        ))}
      </div>
    </main>
  );
}
