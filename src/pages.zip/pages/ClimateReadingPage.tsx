
import { useState } from "react";

const passage = `
Climate change is one of the most significant
environmental challenges facing the world today.
Rising global temperatures affect ecosystems,
agriculture, and human communities.

One major cause is the increasing concentration
of greenhouse gases in the atmosphere. Human
activities, particularly burning fossil fuels
and deforestation, contribute to these emissions.

Scientists have observed changes in rainfall
patterns, rising sea levels, and more frequent
extreme weather events in many regions.

Governments are introducing policies to reduce
emissions, while businesses are investing in
renewable energy technologies. Individuals can
also contribute by conserving energy and reducing
waste.

However, addressing climate change requires
international cooperation and long-term planning.
`;

const questions = [
  {
    question: "What is a major cause of climate change?",
    options: [
      "Greenhouse gas emissions",
      "Ocean exploration",
      "Improved agriculture",
    ],
    answer: 0,
  },
  {
    question: "Which human activity contributes to emissions?",
    options: [
      "Planting trees",
      "Burning fossil fuels",
      "Using public libraries",
    ],
    answer: 1,
  },
  {
    question: "What have scientists observed?",
    options: [
      "Stable sea levels everywhere",
      "No changes in rainfall",
      "Changes in rainfall patterns",
    ],
    answer: 2,
  },
  {
    question: "What are businesses investing in?",
    options: [
      "Renewable energy technologies",
      "More deforestation",
      "Traditional paper records",
    ],
    answer: 0,
  },
  {
    question: "How can individuals contribute?",
    options: [
      "Increasing energy consumption",
      "Reducing waste",
      "Ignoring environmental issues",
    ],
    answer: 1,
  },
  {
    question: "What does climate action require?",
    options: [
      "Only local decisions",
      "Short-term solutions alone",
      "International cooperation",
    ],
    answer: 2,
  },
  {
    question: "Which sector is affected by rising temperatures?",
    options: [
      "Agriculture",
      "Only entertainment",
      "Only transportation",
    ],
    answer: 0,
  },
  {
    question: "What is the main purpose of the passage?",
    options: [
      "To describe a single weather event",
      "To explain climate change and responses to it",
      "To promote one renewable energy company",
    ],
    answer: 1,
  },
];

export default function ClimateReadingPage() {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);

  const score = questions.filter(
    (q, i) => answers[i] === q.answer
  ).length;

  return (
    <main className="mx-auto max-w-5xl p-6">
      <h1 className="text-3xl font-bold">
        Climate Change
      </h1>

      <p className="mt-2 text-gray-500">
        IELTS Reading — Hard
      </p>

      <article className="mt-8 whitespace-pre-line rounded-2xl bg-white p-6 shadow-sm">
        {passage}
      </article>

      <section className="mt-8 space-y-6">
        {questions.map((q, i) => (
          <div key={i} className="rounded-2xl bg-white p-6 shadow-sm">
            <h2 className="font-semibold">
              {i + 1}. {q.question}
            </h2>

            <div className="mt-4 space-y-3">
              {q.options.map((option, j) => (
                <label key={j} className="flex items-center gap-3">
                  <input
                    type="radio"
                    name={`question-${i}`}
                    checked={answers[i] === j}
                    disabled={submitted}
                    onChange={() =>
                      setAnswers({ ...answers, [i]: j })
                    }
                  />
                  {option}
                </label>
              ))}
            </div>
          </div>
        ))}
      </section>

      {!submitted ? (
        <button
          onClick={() => {
  const result = {
    test: "Climate Change",
    score,
    total: questions.length,
    date: new Date().toLocaleDateString(),
  };

  const history = JSON.parse(
    localStorage.getItem("readingHistory") || "[]"
  );

  localStorage.setItem(
    "readingHistory",
    JSON.stringify([...history, result])
  );

  setSubmitted(true);
}}
          disabled={Object.keys(answers).length !== questions.length}
          className="mt-8 rounded-xl bg-violet-600 px-6 py-3 text-white disabled:opacity-50"
        >
          Check Answers
        </button>
      ) : (
        <div className="mt-8 rounded-2xl bg-white p-6 shadow-sm">
          <h2 className="text-xl font-bold">
            Your score: {score}/{questions.length}
          </h2>

          <button
            onClick={() => {
              setAnswers({});
              setSubmitted(false);
            }}
            className="mt-4 rounded-xl bg-violet-600 px-6 py-3 text-white"
          >
            Try Again
          </button>
        </div>
      )}
    </main>
  );
}
