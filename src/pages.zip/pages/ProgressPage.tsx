
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useEffect, useState } from "react";

type TestResult = {
  test: string;
  score: number;
  total: number;
  date: string;
};

export default function ProgressPage() {
  const [writingHistory, setWritingHistory] = useState<
  { id: number; date: string; bandScore?: number }[]
>([]);
  const [history, setHistory] = useState<TestResult[]>([]);
  const [quizHistory, setQuizHistory] = useState<
  { date: string; score: number; total: number }[]
>([]);
 
useEffect(() => {
  const savedWriting = localStorage.getItem("writingHistory");

if (savedWriting) {
  try {
    const parsed = JSON.parse(savedWriting);
    if (Array.isArray(parsed)) {
      setWritingHistory(parsed);
    }
  } catch {
    console.error("Could not load writing history");
  }
}
  const saved = localStorage.getItem("readingHistory");

  if (saved) {
    setHistory(JSON.parse(saved));
  }

  const savedQuizHistory = localStorage.getItem("vocabularyQuizHistory");

  if (savedQuizHistory) {
    setQuizHistory(JSON.parse(savedQuizHistory));
  }
}, []);
  const writingChartData = writingHistory
  .filter(
    (entry) =>
      typeof entry.bandScore === "number" &&
      Number.isFinite(entry.bandScore) &&
      entry.bandScore > 0
  )
  .sort((a, b) => a.id - b.id)
  .map((entry, index) => ({
    essay: `Essay ${index + 1}`,
    band: entry.bandScore,
    date: entry.date,
  }));
  const totalEssays = writingHistory.length;

const writingScores = writingHistory
  .map((entry) => entry.bandScore)
  .filter((score): score is number =>
    typeof score === "number" &&
    Number.isFinite(score) &&
    score > 0
  );

const averageWritingBand =
  writingScores.length > 0
    ? writingScores.reduce((sum, score) => sum + score, 0) /
      writingScores.length
    : null;

const bestWritingBand =
  writingScores.length > 0
    ? Math.max(...writingScores)
    : null;
  const totalTests = history.length;
  const clearHistory = () => {
  const confirmed = window.confirm(
    "Are you sure you want to delete all test results?"
  );

  if (!confirmed) return;

  localStorage.removeItem("readingHistory");
  setHistory([]);
};

const averageScore =
  totalTests > 0
    ? Math.round(
        history.reduce(
          (sum, result) =>
            sum + (result.score / result.total) * 100,
          0
        ) / totalTests
      )
    : 0;

const bestScore =
  totalTests > 0
    ? Math.max(
        ...history.map(
          (result) => (result.score / result.total) * 100
        )
      )
    : 0;
    const chartData = history.map((result, index) => ({
  test: `Test ${index + 1}`,
  score: Math.round((result.score / result.total) * 100),
}));
  const vocabularyChartData = quizHistory.map((result, index) => ({
  test: `Quiz ${index + 1}`,
  score: Math.round((result.score / result.total) * 100),
}));
  return (
    <main className="mx-auto max-w-5xl p-8">
      <h1 className="text-3xl font-bold text-slate-900">
        My Progress
      </h1>

      <p className="mt-2 text-gray-500">
        Track your IELTS Reading performance.
      </p>
      <button
  onClick={clearHistory}
  className="mt-4 rounded-xl border border-red-200 px-4 py-2 text-red-600 hover:bg-red-50"
>
  Clear Test History
</button>
      <div className="mt-8 grid gap-5 md:grid-cols-3">
  {[
    { label: "Tests Completed", value: totalTests },
    { label: "Average Score", value: `${averageScore}%` },
    { label: "Best Score", value: `${Math.round(bestScore)}%` },
  ].map((stat) => (
    <div
      key={stat.label}
      className="rounded-2xl bg-white p-6 shadow-sm"
    >
      <p className="text-sm text-gray-500">{stat.label}</p>

      <h2 className="mt-3 text-3xl font-bold text-violet-600">
        {stat.value}
      </h2>
    </div>
  ))}
</div>
<section className="mt-8 rounded-2xl bg-white p-6 shadow-sm">
  <h2 className="mb-6 text-xl font-semibold">
    Reading Score Progress
  </h2>

  {chartData.length === 0 ? (
    <p className="text-gray-500">
      Complete a reading test to see your progress.
    </p>
  ) : (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="test" />
          <YAxis domain={[0, 100]} />
          <Tooltip />
          <Line
            type="monotone"
            dataKey="score"
            stroke="#7C3AED"
            strokeWidth={3}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )}
</section>

<section className="mt-8 rounded-2xl bg-white p-6 shadow-sm">
  <h2 className="mb-6 text-xl font-semibold">
    Vocabulary Quiz Progress
  </h2>

  {vocabularyChartData.length === 0 ? (
    <p className="text-gray-500">
      Complete a vocabulary quiz to see your progress.
    </p>
  ) : (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={vocabularyChartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="test" />
          <YAxis domain={[0, 100]} unit="%" />
          <Tooltip formatter={(value) => `${value}%`} />
          <Line
            type="monotone"
            dataKey="score"
            stroke="#7C3AED"
            strokeWidth={3}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )}
</section>

      <div className="mt-8 space-y-4">
        {history.length === 0 ? (
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            No test results yet. Complete a reading test!
          </div>
        ) : (
          history.map((result, index) => (
            <div
              key={index}
              className="rounded-2xl bg-white p-6 shadow-sm"
            >
              <h2 className="text-xl font-semibold">
                {result.test}
              </h2>

              <p className="mt-2 text-gray-500">
                Date: {result.date}
              </p>

              <p className="mt-2 font-bold text-violet-600">
                Score: {result.score}/{result.total}
              </p>
            </div>
          ))
        )}
      </div>


<div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-3">
  <div className="rounded-2xl bg-white p-5 shadow-sm">
    <p className="text-sm text-gray-500">Essays Evaluated</p>
    <p className="mt-2 text-3xl font-bold text-purple-600">
      {totalEssays}
    </p>
  </div>

  <div className="rounded-2xl bg-white p-5 shadow-sm">
    <p className="text-sm text-gray-500">Average Writing Band</p>
    <p className="mt-2 text-3xl font-bold text-purple-600">
      {averageWritingBand !== null
        ? averageWritingBand.toFixed(1)
        : "—"}
    </p>
  </div>

  <div className="rounded-2xl bg-white p-5 shadow-sm">
    <p className="text-sm text-gray-500">Best Writing Band</p>
    <p className="mt-2 text-3xl font-bold text-purple-600">
      {bestWritingBand !== null
        ? bestWritingBand.toFixed(1)
        : "—"}
    </p>
  </div>
</div>

<section className="mt-8 rounded-2xl border border-purple-100 bg-white p-6 shadow-sm">
  <h2 className="text-xl font-bold text-gray-900">
    IELTS Writing Progress
  </h2>

  <p className="mt-2 text-sm text-gray-500">
    Track your estimated IELTS Writing band scores over time.
  </p>

  {writingChartData.length === 0 ? (
    <p className="mt-6 text-gray-500">
      No writing scores yet. Complete an IELTS Writing evaluation to see your progress.
    </p>
  ) : (
    <div className="mt-6 h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={writingChartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="essay" />
          <YAxis domain={[0, 9]} ticks={[0, 3, 4, 5, 6, 7, 8, 9]} />
          <Tooltip />
          <Line
            type="monotone"
            dataKey="band"
            name="Estimated Band"
            stroke="#7c3aed"
            strokeWidth={3}
            dot={{ r: 5 }}
            activeDot={{ r: 7 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )}

  <p className="mt-3 text-xs text-gray-400">
    Scores are unofficial AI estimates, not official IELTS results.
  </p>
</section>

    </main>
  );
}
