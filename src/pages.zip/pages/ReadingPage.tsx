
import { useEffect, useState } from "react";

const questions = [
  {
    question: "Why are urban gardens becoming popular?",
    options: [
      "They replace all supermarkets",
      "They provide fresh food and green spaces",
      "They require no maintenance",
    ],
    answer: 1,
    explanation: "The passage says urban gardens provide fresh food and create green spaces in cities.",
  },
  {
    question: "What can people learn from urban gardening?",
    options: [
      "How to grow plants",
      "How to build skyscrapers",
      "How to drive buses",
    ],
    answer: 0,
    explanation: "The passage explains that urban gardening helps communities learn about growing plants.",
  },
  
{
  question: "Urban gardens can only be created on rooftops.",
  options: ["True", "False", "Not Given"],
  answer: 1,
  explanation:
    "The passage mentions rooftops, balconies, and small gardens. Therefore, the statement is False.",
},

{
  question: "Most urban gardeners spend more than five hours a week gardening.",
  options: ["True", "False", "Not Given"],
  answer: 2,
  explanation:
    "The passage does not mention how many hours people spend gardening. Therefore, the correct answer is Not Given.",
},


];

export default function ReadingPage() {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  
const [timeLeft, setTimeLeft] = useState(10* 60);


useEffect(() => {
  if (submitted) return;

  if (timeLeft === 0) {
    setSubmitted(true);
    return;
  }

  const timer = setTimeout(() => {
    setTimeLeft((previous) => previous - 1);
  }, 1000);

  return () => clearTimeout(timer);
}, [timeLeft, submitted]);

const minutes = Math.floor(timeLeft / 60);
const seconds = timeLeft % 60;

  const score = questions.filter(
    (q, i) => answers[i] === q.answer
  ).length;

  return (
    <main className="mx-auto max-w-5xl p-6">
      <h1 className="text-3xl font-bold">IELTS Reading Practice</h1>
      
<div className="mt-4 inline-flex rounded-xl bg-violet-100 px-4 py-2 font-semibold text-violet-700">
  Time remaining: {minutes}:{String(seconds).padStart(2, "0")}
</div>

      <p className="mt-2 text-gray-500">
        Read the passage and answer the questions.
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <article className="rounded-2xl bg-white p-6 shadow-sm">
          <h2 className="mb-4 text-xl font-semibold">
            Urban Gardening
          </h2>
          <p className="leading-8 text-gray-600">
            Urban gardening is becoming increasingly popular in
            cities around the world. People grow vegetables,
            fruits, and flowers in small gardens, on rooftops,
            and even on balconies. These gardens provide fresh
            food and create green spaces in busy urban areas.
            They also help communities learn about growing
            plants and caring for the environment.
          </p>
        </article>

        <section className="rounded-2xl bg-white p-6 shadow-sm">
          <h2 className="mb-5 text-xl font-semibold">Questions</h2>

          {questions.map((q, i) => (
            <div key={i} className="mb-7">
              <h3 className="mb-3 font-medium">
                {i + 1}. {q.question}
              </h3>

              {q.options.map((option, j) => (
                <label
                  key={j}
                  className="mb-2 flex cursor-pointer gap-3 rounded-lg border p-3"
                >
                  <input
                    type="radio"
                    name={`question-${i}`}
                    checked={answers[i] === j}
                    disabled={submitted}
                    onChange={() =>
                      setAnswers({ ...answers, [i]: j })
                    }
                  />
                  <span>{option}</span>
                </label>
              ))}
              
{submitted && (
  <div
    className={`mt-3 rounded-xl p-4 ${
      answers[i] === q.answer
        ? "bg-green-50 text-green-800"
        : "bg-red-50 text-red-800"
    }`}
  >
    <p className="font-semibold">
      {answers[i] === q.answer
        ? "✓ Correct!"
        : "✗ Incorrect"}
    </p>

    <p className="mt-2 text-sm">
      Correct answer: {q.options[q.answer]}
    </p>

    <p className="mt-2 text-sm">
      {q.explanation}
    </p>
  </div>
)}
  
            </div>
          ))}

          {!submitted ? (
            <button
              onClick={() => {
  const result = {
    test: "Urban Gardening",
    score,
    total: questions.length,
    date: new Date().toLocaleDateString(),
  };

  const history = JSON.parse(
    localStorage.getItem("readingHistory") || "[]"
  );

  localStorage.setItem(
    "readingHistory",
    JSON.stringify([...history, result])
  );

  setSubmitted(true);
}}
              disabled={Object.keys(answers).length !== questions.length}
              className="rounded-xl bg-violet-600 px-5 py-3 text-white disabled:opacity-50"
            >
              Check Answers
            </button>
          ) : (
            <div>
              <p className="font-semibold text-violet-700">
                Your score: {score}/{questions.length}
              </p>
              <button
                onClick={() => {
                  setAnswers({});
                  setTimeLeft(10 * 60);
                  setSubmitted(false);
                }}
                className="mt-4 rounded-xl bg-violet-600 px-5 py-3 text-white"
              >
                Try Again
              </button>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
