
import { useEffect, useState } from "react";

const passage = `
Technology has changed the way students learn.
Many schools now use digital textbooks, online
platforms, and educational applications.

One important advantage is flexibility. Students
can access lessons from home and study at their
own pace. Online resources also allow learners
to review difficult topics several times.

However, technology can create challenges.
Some students become distracted by social media,
while others do not have reliable internet access.

Teachers play an important role in helping
students use technology effectively. Combining
traditional teaching methods with digital tools
can create a balanced learning environment.
`;

const questions = [
  {
    question: "What is one advantage of online learning?",
    options: [
      "It removes the need for teachers",
      "Students can study at their own pace",
      "It guarantees perfect grades",
    ],
   answer: 1,
   explanation: "The passage explains that online learning allows students to study at their own pace.",
  },
  {
    question: "What can distract students?",
    options: [
      "Social media",
      "Digital textbooks",
      "Teachers",
    ],
    answer: 0,
    explanation: "The passage says social media can distract students.",
  },
  {
    question: "What problem do some students face?",
    options: [
      "Too many teachers",
      "Unreliable internet access",
      "Too many classrooms",
    ],
    answer: 1,
    explanation: "Some students do not have reliable internet access.",
  },
  {
    question: "Why are online resources useful?",
    options: [
      "They replace all exams",
      "They make school unnecessary",
      "They allow students to review topics",
    ],
    answer: 2,
    explanation: "Online resources allow learners to review difficult topics several times.",
  },
  {
    question: "What role do teachers play?",
    options: [
      "They help students use technology effectively",
      "They stop students using computers",
      "They replace online platforms",
    ],
    answer: 0,
    explanation: "Teachers help students use technology effectively.",
  },
  {
    question: "What creates a balanced learning environment?",
    options: [
      "Only traditional teaching",
      "Only digital learning",
      "Combining traditional and digital methods",
    ],
    answer: 2,
    explanation: "Combining traditional teaching methods with digital tools creates a balanced learning environment.",
  },
];

export default function TechnologyReadingPage() {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(15*60);

useEffect(() => {
  if (submitted) return;

if (timeLeft <= 0) {
  setSubmitted(true);
  return;
}

  const timer = setTimeout(() => {
    setTimeLeft((previous) => previous - 1);
  }, 1000);

  return () => clearTimeout(timer);
}, [timeLeft, submitted]);

const minutes = Math.floor(timeLeft / 60);
const seconds = timeLeft % 60;

  const score = questions.filter(
    (q, i) => answers[i] === q.answer
  ).length;

  return (
    <main className="mx-auto max-w-5xl p-6">
      <h1 className="text-3xl font-bold">
        Technology in Education
      </h1>

      <p className="mt-2 text-gray-500">
        IELTS Reading — Medium
      </p>
      <div className="mt-4 inline-flex rounded-xl bg-violet-100 px-4 py-2 font-semibold text-violet-700">
        Time remaining: {minutes}:{String(seconds).padStart(2, "0")}
      </div>

      <article className="mt-8 whitespace-pre-line rounded-2xl bg-white p-6 shadow-sm">
        {passage}
      </article>

      <section className="mt-8 space-y-6">
        {questions.map((q, i) => (
          <div key={i} className="rounded-2xl bg-white p-6 shadow-sm">
            <h2 className="font-semibold">
              {i + 1}. {q.question}
            </h2>

            <div className="mt-4 space-y-3">
              {q.options.map((option, j) => (
                <label key={j} className="flex items-center gap-3">
                  <input
                    type="radio"
                    name={`question-${i}`}
                    checked={answers[i] === j}
                    disabled={submitted}
                    onChange={() =>
                      setAnswers({ ...answers, [i]: j })
                    }
                  />
                  {option}
                </label>
              ))}
            </div>
            
{submitted && (
  <div
    className={`mt-4 rounded-xl p-4 ${
      answers[i] === q.answer
        ? "bg-green-50 text-green-800"
        : "bg-red-50 text-red-800"
    }`}
  >
    <p className="font-semibold">
      {answers[i] === q.answer
        ? "✓ Correct!"
        : "✗ Incorrect"}
    </p>

    <p className="mt-2 text-sm">
      Correct answer: {q.options[q.answer]}
    </p>

    <p className="mt-2 text-sm">
      Explanation: {q.explanation}
    </p>
  </div>
)}

          </div>
        ))}
      </section>

      {!submitted ? (
        <button
          onClick={() => {
  const result = {
    test: "Technology in Education",
    score,
    total: questions.length,
    date: new Date().toLocaleDateString(),
  };

  const history = JSON.parse(
    localStorage.getItem("readingHistory") || "[]"
  );

  localStorage.setItem(
    "readingHistory",
    JSON.stringify([...history, result])
  );

  setSubmitted(true);
}}
          disabled={Object.keys(answers).length !== questions.length}
          className="mt-8 rounded-xl bg-violet-600 px-6 py-3 text-white disabled:opacity-50"
        >
          Check Answers
        </button>
      ) : (
        <div className="mt-8 rounded-2xl bg-white p-6 shadow-sm">
          <h2 className="text-xl font-bold">
            Your score: {score}/{questions.length}
          </h2>

          <button
            onClick={() => {
              setAnswers({});
              setTimeLeft(15*60);
              setSubmitted(false);
            }}
            className="mt-4 rounded-xl bg-violet-600 px-6 py-3 text-white"
          >
            Try Again
          </button>
        </div>
      )}
    </main>
  );
}
