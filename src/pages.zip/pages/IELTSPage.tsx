
import { Link } from "react-router-dom";
import { BookOpen, Headphones, PenLine, Mic } from "lucide-react";

const modules = [
  {
    name: "Reading",
    icon: BookOpen,
    description: "Practice reading passages and questions.",
    path: "/ielts/reading/tests",
    button: "Start Practice",
  },
  {
    name: "Listening",
    icon: Headphones,
    description: "Improve listening comprehension.",
    path: "/ielts/listening",
    button: "Start Listening",
  },
  {
    name: "Writing",
    icon: PenLine,
    description: "Learn essay structure, develop ideas, and improve your writing.",
    path: "/ielts/writing",
    button: "Start Writing",
  },
  {
    name: "Speaking",
    icon: Mic,
    description: "Prepare for IELTS speaking interviews.",
    path: null,
    button: "Coming soon",
  },
  {
  name: "Topic Academy",
  icon: BookOpen,
  description:
    "Explore IELTS topics, develop ideas, and learn academic vocabulary.",
  path: "/ielts/topics",
  button: "Explore Topics",
  },
];

export default function IELTSPage() {
  return (
    <main className="mx-auto max-w-5xl p-6">
      <h1 className="text-3xl font-bold text-[#1E2340]">
        IELTS Preparation
      </h1>

      <p className="mt-2 text-gray-500">
        Choose a skill and start improving your English.
      </p>

      <div className="mt-8 grid gap-5 sm:grid-cols-2">
        {modules.map(({ name, icon: Icon, description, path, button }) => (
          <div
            key={name}
            className="rounded-2xl bg-white p-6 shadow-sm"
          >
            <Icon className="mb-4 text-violet-600" size={30} />

            <h2 className="text-xl font-semibold">{name}</h2>

            <p className="mt-2 text-gray-500">{description}</p>

            {path ? (
              <Link
                to={path}
                className="mt-5 inline-block rounded-xl bg-violet-600 px-5 py-3 font-medium text-white hover:bg-violet-700"
              >
                {button}
              </Link>
            ) : (
              <button
                type="button"
                disabled
                className="mt-5 rounded-xl bg-violet-100 px-4 py-2 text-violet-600"
              >
                Coming soon
              </button>
            )}
          </div>
        ))}
      </div>
    </main>
  );
}
