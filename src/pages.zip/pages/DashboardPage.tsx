
import {
  BookOpen,
  Headphones,
  Mic,
  PenLine,
  Sparkles,
} from "lucide-react";
const skills = [
  { name: "Reading", icon: BookOpen, description: "Practice comprehension" },
  { name: "Listening", icon: Headphones, description: "Improve listening skills" },
  { name: "Writing", icon: PenLine, description: "Get writing feedback" },
  { name: "Speaking", icon: Mic, description: "Practice speaking" },
];

export default function DashboardPage() {
  return (
  <div className="min-h-screen bg-[#F8F9FD] text-[#1E2340] md:flex">

    <div className="min-w-0 flex-1 p-8">
      <header className="mb-10 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-violet-600">
          PrepMaster AI
        </h1>
        <span className="rounded-full bg-white px-4 py-2 shadow-sm">
          Student Dashboard
        </span>
      </header>

      <main className="mx-auto max-w-5xl">
        <h2 className="text-3xl font-bold">Welcome back! 👋</h2>
        <p className="mt-2 text-gray-500">
          Let's get closer to your IELTS goals.
        </p>

        <section className="my-8 rounded-2xl bg-violet-600 p-6 text-white">
          <h3 className="text-xl font-semibold">Your IELTS Journey</h3>
          <p className="mt-2">Target Band: 7.5</p>
          <div className="mt-4 h-3 rounded-full bg-violet-400">
            <div className="h-3 w-[35%] rounded-full bg-white" />
          </div>
          <p className="mt-2 text-sm">35% progress — demo data</p>
        </section>

        <h3 className="mb-4 text-xl font-semibold">IELTS Practice</h3>
        <div className="grid gap-5 sm:grid-cols-2">
          {skills.map(({ name, icon: Icon, description }) => (
            <article
              key={name}
              className="rounded-2xl bg-white p-6 shadow-sm"
            >
              <Icon className="mb-4 text-violet-600" size={30} />
              <h4 className="text-lg font-semibold">{name}</h4>
              <p className="mt-2 text-gray-500">{description}</p>
            </article>
          ))}
        </div>

        <section className="mt-8 rounded-2xl bg-white p-6 shadow-sm">
          <div className="flex items-center gap-2">
            <Sparkles className="text-violet-600" />
            <h3 className="text-xl font-semibold">AI Study Coach</h3>
          </div>
          <p className="mt-3 text-gray-500">
            Your personalized study recommendations will appear here.
          </p>
        </section>
            </main>
    </div>
  </div>
  );
}
