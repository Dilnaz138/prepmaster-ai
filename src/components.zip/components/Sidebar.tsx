import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  BookOpen,
  Calculator,
  Sparkles,
  ChartNoAxesColumn,
  GraduationCap,
} from "lucide-react";


const menuItems = [
  { name: "Dashboard", icon: LayoutDashboard, path: "/" },
  { name: "IELTS Preparation", icon: BookOpen, path: "/ielts" },
  { name: "SAT Preparation", icon: Calculator, path: "/sat" },
  { name: "AI Tutor", icon: Sparkles, path: "/ai-tutor" },
  { name: "My Progress", icon: ChartNoAxesColumn, path: "/progress" },
];


export default function Sidebar() {
  return (
    <aside className="w-full shrink-0 bg-white border-r border-gray-100 p-4 md:min-h-screen md:w-60">
      <div className="flex items-center gap-2 mb-12">
        <GraduationCap className="text-violet-600" size={30} />
        <h1 className="text-xl font-bold text-violet-600">
          PrepMaster AI
        </h1>
      </div>

      
<nav className="space-y-2">
  {menuItems.map(({ name, icon: Icon, path }) => (
    <NavLink
      key={name}
      to={path}
      end={path === "/"}
      className={({ isActive }) =>
        `flex items-center gap-3 rounded-xl p-3 transition ${
          isActive
            ? "bg-violet-100 text-violet-700"
            : "text-gray-500 hover:bg-gray-50"
        }`
      }
    >
      <Icon size={20} />
      <span className="font-medium">{name}</span>
    </NavLink>
  ))}
</nav>

    </aside>
  );
}
